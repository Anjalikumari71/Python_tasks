list = []
print(f"Number of devces: {len(list)} ")
count = 0
while count < 5 :
    device_name = input("Enter a device name: ")
    list.append(device_name)
print("Number of items: ", count(device_name) )
for device in list:
    print(device)
d= input("Enter device name to search: ")
if(d in list):
    print(f"Device is found at  {list.index(d)} level" )
else:
    list.append(d)
    print(f"Device {d} added at {list.index(d)} level")
    print("Updated list of devices: ", list)
    for device in list:
        print(device)