emp = ["101,raj,sales,pune,1000",
       "102,anu,hr,hyderabad,2000",
       "103,leo,sales,noida, 3000",
       "104,theeb,prod,mumbai,4000"]
sum=0
for e in emp:
    v = e.split(",")
    empId = v[0]
    emp_name = v[1]
    emp_dept = v[2]
    emp_city = v[3]
    emp_salary = v[4]
    print(f"Employee name: {emp_name.title()} Employee city: {emp_city.upper()}")
    sum += int(emp_salary)

print("Total salary: " + str(sum))
