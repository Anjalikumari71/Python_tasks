file_info= [
    'emp.csv:123:2KB:userA',
    ''
]