import pprint
hosts = {}
count =0
while count < 5 :
    host_alias = input("Enter host alias: ")
    if host_alias in hosts:
        print(f"Alias {host_alias} already exists with IP {hosts[host_alias]}")
        print("Enter a different alias: ")
        continue
    ip_address = input("Enter IP address: ")
    hosts[host_alias] = ip_address
    count += 1
print("Hosts \t IPAddress")
for var in hosts:
    print(f"{var}- {hosts[var]}")
    print(" ")
entered = input("Enter alias name to search: ")

if entered in hosts:
    hosts[entered] = "127.0.0.1"
    print(f"The IP address for {entered} is {ip_address}")
else:
    hosts[entered] = "127.0.0.1"
    print(f"The IP address for {entered} is {hosts[entered]}")
print("Updated dictionary")
pprint.pprint(hosts)    