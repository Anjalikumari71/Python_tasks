#tuple of lists

import pprint
L=[]
L.append(('flask','version is1.2',5000))
L.append(('django','version is3.1',8000))
L.append(('fastapi','version is0.65',9000))
L.append(('tornado','version is6.1',7000))
print(L[1])
if L[2][-1] == 9000:
    web_app = L[2][0]
    print(f"The web app running on port 9000 is {web_app}")
else:
    print("Invalid port")
L.append(('flask','version is1.6',5000))
pprint.pprint(L)