import time
fobj = open('pin_history.log','a') #append mode
pin =1234
count = 0
while(count<3):
    count = count+1
    p =input("Enter a pin number: ")
    if(int(p) == pin):
        fobj.write(f"Successful login at {time.ctime()}\n")
        fobj.write(f"Success pin is matched = {count}\n")
        print(f"success - pin is matched = {count}")
        break
    else:
        fobj.write(f"Failed - user input pin {p} is not matched")
        fobj.write(f"Pin entry date/time is: {time.ctime()}\n")

if(int(p) != pin):
    print("Failed - maximum attempts reached.")
    fobj.write(f"Sorry your pin is blocked - maximum attempts reached at {time.ctime()}\n")
fobj.close()