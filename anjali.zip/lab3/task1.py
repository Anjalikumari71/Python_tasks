file = open(".\\Python_Training\\lab3\\data.txt","r")
content = file.read()
file.close()
print(content)