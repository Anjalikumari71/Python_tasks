def factorial(n):
	result = 1
	for number in range(2, n + 1):
		result *= number
	return result


try:
	n = int(input("Enter a non-negative integer: "))
	if n < 0:
		print("Factorial is not defined for negative numbers.")
	else:
		print(f"{n}! = {factorial(n)}")
except ValueError:
	print("Please enter a valid integer.")
