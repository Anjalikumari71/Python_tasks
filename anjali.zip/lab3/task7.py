def fa():
    return ""
def fb():
    findex = 45
    return findex
def fc():
    return "STDOUT", "STDERR"
rv = fb()
print(rv)
type(rv)