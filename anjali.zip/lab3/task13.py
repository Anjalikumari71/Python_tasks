# step 1 Empty dictionary
d={}
#  step - 2 File Handling
fobj = open('network.cfg','r') 
L = fobj.readlines()
fobj.close()
for var in  L:
    var = var.strip() # remove \n
    K,V = var.split('=') #split each line into multiple values
    d[K] = V # adding new data to dictionary

#step 3 Display key and value
for var in d:
    print(f"{var} - {d[var]}")

