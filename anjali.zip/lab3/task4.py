fobj = open("","r")
L = fobj.readlines()
fobj.close()
for var in L:
    if 'sales' in var:
        print(var.strip())