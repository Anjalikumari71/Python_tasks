with open("C:\\Users\\anjkuma4\\emp.csv",'r') as fobj:
    L = fobj.readlines()
    for var in L:
        var = var.strip()
        eid,ename,eplace,edept,ecost = var.split(',')
        print(f'{ename.title()} {edept.upper()}')
print("End of line")