wobj = open(".\\lab3\\data.txt","w")
wobj.write("This is a test line.\n")
wobj.close()