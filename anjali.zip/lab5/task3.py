import re
s1 = '101,raj,sales,pune'
s2 = 'sales,raj,pune'
s3 = 'sales'
print(re.search('e$', s1))
print(re.search('s$', s2))
print(re.search('s$', s3))