'''
write a python
'''
import os
import re
files = os.listdir('C:\\Users\\anjkuma4\\')
for var in files:
    if re.search("pdf$",var):
        print(var)