import re
s = "This is a sample string for regex or search."
res = re.search('for', s)
print(res)
print(bool(res))
