import re
s1 = '101,raj,sales,pune'
s2 = 'sales,raj,pune'
s3 = 'sales'
print(re.search('sales', s1))
print(re.search('^sales', s2))
print(re.search('^sales', s3))

s4 = 'marketing, selling, e-commerce'
print('^ ',s4)
print(re.search('^marketing', s4))