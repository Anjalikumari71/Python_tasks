import re
s1 = '101,raj,sales,pune'
res = re.search("...sales.." ,s1)
print(res)