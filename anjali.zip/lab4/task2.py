fobj = open('C:\\Users\\anjkuma4\\emp.csv','r')
L = fobj.readlines()
fobj.close()
total = 0
for var in L:
    if  "sales" in var:
        cost = var.split(",")[-1]
        total += float(cost)
print(f"Total sales cost: {total}")