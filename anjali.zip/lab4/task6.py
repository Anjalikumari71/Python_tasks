class app:
    app_name = "demoApp"
    app_port = 1000
for var in app.__dict__:
    print(f"{var}: {app.__dict__.get(var)}")
print("")
print(app.app_name)
print(app.app_port)
