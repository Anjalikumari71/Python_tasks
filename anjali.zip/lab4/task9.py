class Enrollment:
    ename = ""
    edob = ""
eobj1 = Enrollment()
eobj1.ename = "anjali"
eobj1.edob = "1st jan"

print(eobj1.ename)
print(eobj1.edob)

eobj2 = Enrollment()
eobj2.ename = "rahul"
eobj2.edob = "2nd feb"

print(eobj2.ename)
print(eobj2.edob)