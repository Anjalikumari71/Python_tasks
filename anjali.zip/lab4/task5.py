#object-oriented-programming

class app:
    app_name = "demoApp"
    app_port = 1000
print(app.app_name)
app.app_port = 3000
print(app.app_port)
app.app_config = 'app.cnf'
print(app.app_config)